#!/bin/sh
pytest
